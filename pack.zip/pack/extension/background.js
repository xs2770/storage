chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getCookies') {
        (async () => {
            try {
                const urls = ['https://www.google.com', 'https://labs.google'];
                let allCookies = [];

                for (const url of urls) {
                    const cookies = await chrome.cookies.getAll({ url });
                    allCookies = allCookies.concat(cookies);
                }

                const cookieHeader = allCookies
                    .map(c => `${c.name}=${c.value}`)
                    .filter((v, i, a) => a.indexOf(v) === i)
                    .join('; ');

                sendResponse({ cookieHeader });
            } catch (err) {
                console.error('Failed to get cookies:', err);
                sendResponse({ cookieHeader: '' });
            }
        })();

        // ❗️Phải return true để giữ callback `sendResponse`
        return true;
    }
});
