document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ action: 'getCookies' }, (response) => {
        console.log("Cookie header:", response);

        const textarea = document.getElementById('cookieHeader');
        textarea.value = response.cookieHeader;

        document.getElementById('copyBtn').addEventListener('click', () => {
            navigator.clipboard.writeText(textarea.value);
            alert('Copied!');
        });
    });
});
